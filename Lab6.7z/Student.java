public class Student extends Member{

  private int studentID;
  private String type;


  public Student(){
    super();
    this.studentID = -1;
    this.type = "";
  }

  public Student(String firstName, String lastName, int studentID, String type){
    super(firstName, lastName);
    this.studentID = studentID;
    this.type = type;
  }




  public void setStudentID(int idNumber)
  {
    this.studentID = idNumber;
  }

  public int getStudentID(){
    return this.studentID;
  }

  public void setType(String type){
    this.type = type;
  }

  public String getType(){
    return this.type;
  }

  public boolean equals(Object obj) {
    if(obj == null) {
      return false;
    } else if(obj.getClass() != this.getClass() ) {
      return false;
    }

    Student toCompare = (Student) obj;
    if( (toCompare.getFirstName() == this.getFirstName() ) && (toCompare.getLastName() == this.getLastName() ) && (toCompare.getStudentID() == this.getStudentID() ) && (toCompare.getType() == this.getType() ) ) {
      return true;
    } else return false;

  }

}
