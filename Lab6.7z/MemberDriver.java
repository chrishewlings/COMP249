import java.io.*;

class AlreadyWrittenException extends Exception {

}

public class MemberDriver{
  public static void main(String[] args)  throws IOException {


    Student student1 = new Student("Jerry","Seinfeld", 66, "Full Time");
    Student student2 = new Student("George","Costanza", 67, "Full Time");
    Student student3 = new Student("Elaine","Benes", 68, "Full Time");

    Employee employee1 = new Employee("Dennis","Reynolds", 81);
    Employee employee2 = new Employee("Dee","Reynolds", 82);
    Employee employee3 = new Employee("Charlie","Kelly", 83);

    Member[] memberArray = new Member[6];
    memberArray[0] = student1;
    memberArray[1] = student2;
    memberArray[2] = student3;
    memberArray[3] = employee1;
    memberArray[4] = employee2;
    memberArray[5] = employee3;

    FileInputStream fileIn = null;
    ObjectInputStream objIn = null;
    FileOutputStream fileOut = null;
    ObjectOutputStream objOut = null;

    try {
      fileIn = new FileInputStream("output.bin");
      objIn = new ObjectInputStream(fileIn);
      Member[] existingInstance = (Member[]) objIn.readObject();

      fileOut = new FileOutputStream("output.bin");
      objOut = new ObjectOutputStream(fileOut);

      for(int i = 0; i < memberArray.length; i++ ){
        for(int j =0 ; i < existingInstance.length; j++ )
        {
          if(existingInstance[j].equals(memberArray[i]) ) {
            throw new AlreadyWrittenException();
          }
        }
      }

    objOut.writeObject(memberArray);
    objOut.close();
    fileOut.close();

    } catch(AlreadyWrittenException e) {
      System.out.println("One or more data members exists in the file already.");
      System.exit(255);
    } catch(IOException e) {
      System.out.println("File not found or error accessing it");
    } catch(ClassNotFoundException e) {
      System.out.println("Class not found.");
    }

    /*fileOut = new FileOutputStream("output.bin");
    objOut = new ObjectOutputStream(fileOut);
    objOut.writeObject(memberArray);
    objOut.close();
    fileOut.close();*/

  }
}
