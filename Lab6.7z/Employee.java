public class Employee extends Member{

  private int employeeID;

  public Employee(){
    super();
    this.employeeID = -1;
    }

  public Employee(String firstName, String lastName, int employeeID){
    super(firstName, lastName);
    this.employeeID = employeeID;
  }

    public void setEmployeeID(int idNumber){
      this.employeeID = idNumber;
    }

    public int getEmployeeID(){
      return this.employeeID;
    }

    public boolean equals(Object obj) {
      if(obj == null) {
        return false;
      } else if(obj.getClass() != this.getClass() ) {
        return false;
      }

      Employee toCompare = (Employee) obj;
      if( (toCompare.getFirstName() == this.getFirstName() ) && (toCompare.getLastName() == this.getLastName() ) && (toCompare.getEmployeeID() == this.getEmployeeID() ) ) {
        return true;
      } else return false;

    }



}
