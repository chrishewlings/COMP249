<?php
  if(count($_POST) != 2) {
    echo "Input was malformed; aborting.";
  }

  function readFromLoginFile() {
    $userInfoFile = fopen("./data/login.txt",r) or die("Error opening login file!");

    while( $line = fgets($userInfoFile)) {
      $entry = explode( ":", $line );
      $username = $entry[0];
      $password = $entry[1];
      $userDataArray[$username] = $password;

    }
    return $userDataArray;
  }

  function checkIfUserExists($username, $userDataArray) {
    if( array_key_exists($username, $userDataArray)) {
      return true;
    } else return false;
  }

  $userDataArray = readFromLoginFile();
  if( checkIfUserExists("user1", $userDataArray)) {
    echo "Chris is in the array already";
  } else {
    echo "not found";
  }


?>
