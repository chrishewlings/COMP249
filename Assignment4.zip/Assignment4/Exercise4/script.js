
function clearMain() {
  document.getElementById("mainForm").innerHTML = "";
}

function loginForm() {
  form = document.getElementById("mainForm");
  form.action = "login.php";

  var fieldSet = document.createElement('fieldset');
  var legend = document.createElement('legend');
  legend.innerHTML = "Login or Create an Account";

  var lineBreak = document.createElement('br');

  var userNameLabel = document.createElement('label');
  userNameLabel.innerHTML = "Username: ";
  var userName = document.createElement('input');
  userName.setAttribute("type", "text");
  userName.setAttribute("name", "userName");

  var passwordLabel = document.createElement('label');
  passwordLabel.innerHTML = "Password: ";
  var password = document.createElement('input');
  password.setAttribute("type", "password");
  password.setAttribute("name", "password");

  var submitButton = document.createElement('input');
  submitButton.setAttribute("type", "submit");
  submitButton.setAttribute("value", "Login");

  var returnButton = document.createElement('input');
  returnButton.setAttribute("type", "button");
  returnButton.setAttribute("value", "Return...");
  returnButton.setAttribute("onClick", "window.location.reload()");

  form.appendChild(fieldSet);
  fieldSet.appendChild(legend);
  fieldSet.appendChild(userNameLabel);
  fieldSet.appendChild(userName);
  fieldSet.appendChild(lineBreak);
  fieldSet.appendChild(passwordLabel);
  fieldSet.appendChild(password);
  fieldSet.appendChild(lineBreak);
  fieldSet.appendChild(submitButton);
  fieldSet.appendChild(returnButton);

}
