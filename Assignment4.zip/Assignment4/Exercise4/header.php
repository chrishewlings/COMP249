<?php
  echo "<div id=\"headerimg\"><img src=\"./images/homeicon.svg\" width=\"100\" height=\"100\"></div>";
  echo "<h1>Apartment Finder by Chris</h1>";
?>
