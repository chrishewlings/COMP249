<?php
  
  echo "<h3>Privacy/Disclaimer Statement:</h3>";
  echo "We take privacy seriously. Your information will not be sold or misused.  We assume no liability from results derived from incorrect information.";
?>
