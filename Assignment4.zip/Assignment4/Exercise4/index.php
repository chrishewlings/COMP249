<!DOCTYPE html>
<!--  images sourced from openclipart user mrjeremiahross -->

<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Exercise 4</title>
  <script type="text/javascript" src="script.js"></script>
</head>
<body>
<div id="header">
  <?php include 'header.php' ?>
</div>
<div id="mainBody">
  <form id="mainForm" action="search.php" method="post">
			<fieldset id="fieldset01">
			<legend id="legend01">Renter(s) information</legend>
				<p class="question">How many people will live in the apartment?
					<input type = "number" name="howManyPeople" id="howManyPeople" min="0" max="5"/>
				</p>

				<p class="question">Smoker? &nbsp;
					<input type="radio" name="isSmoker" id="yes" /><label for="yes">Yes</label>
					<input type="radio" name="isSmoker" id="no" /><label for="no">No</label>
				</p>

				<p class="question">Any pets?<br>

					<input type="checkbox" name="hasPets" id="cats" /><label for="cats">Cat(s)</label> <br>
					<input type="checkbox" name="hasPets" id="dogs" /><label for="dogs">Dog(s)</label> <br>
					<input type="checkbox" name="hasPets" id="other" /><label for="other">Specify:</label>
					<input type="text" name="otherPets" id="otherPets" /> <br>
					<input type="checkbox" name="hasPets" id ="none" /><label for="none">No Pets</label><br>
				</p>

			</fieldset>

			<fieldset id="fieldset02">
					<legend id="legend02">What are you looking for?</legend>
					<ul>
						<li>
							<p class="question">
								Size of apartment:<br>
								<input type="checkbox" name="aptSize" id ="Studio" /><label for="Studio">Studio</label>
								<input type="checkbox" name="aptSize" id ="threeAndAHalf" /><label for="threeAndAHalf">3&frac12;</label>
								<input type="checkbox" name="aptSize" id ="fourAndAHalf" /><label for="fourAndAHalf">4&frac12;</label>
								<input type="checkbox" name="aptSize" id="fiveAndAHalf" /><label for="fiveAndAHalf">5&frac12;</label>
								<input type="checkbox" name="aptSize" id ="moreThanFive" /><label for="moreThanFive">More than 5&frac12;</label>
							</p>
						</li>

						<li>
							<p class="question">
								Do you have preferred locations?<br>
								<input type="checkbox" name="preferredLocation" id ="WestIsland" /><label for="WestIsland">West Island</label>
								<input type="checkbox" name="preferredLocation" id ="Downtown" /><label for="Downtown">Downtown</label>
								<input type="checkbox" name="preferredLocation" id ="LowerWestmount" /><label for="LowerWestmount">Lower Westmount</label>
								<input type="checkbox" name="preferredLocation" id="NDG" /><label for="NDG">NDG</label>
								<input type="checkbox" name="preferredLocation" id ="EastEnd" /><label for="EastEnd">East End of Island</label>
								<input type="checkbox" name="preferredLocation" id ="DontCare" /><label for="DontCare">Don't care</label>
							</p>
						</li>

						<li>
							<p class="question">
								Price Range/month:<br>
								<select name="priceRange">
									<option id = "underFive"> &lt;$500 </option>
									<option id = "fiveToSeven"> $500-$700 </option>
									<option id = "sevenTo1K">  $700-$1000 </option>
									<option id = "noPriceLimit"> No Price Limit </option>
								</select>
							</p>
						</li>

						<li>
							<p class="question">
								Would be nice to have <br>
								<input type="checkbox" name="niceToHave" id ="firePlace" /><label for="firePlace">Fire place</label>
								<input type="checkbox" name="niceToHave" id ="laundromat" /><label for="laundromat">Laundromat in building</label>
								<input type="checkbox" name="niceToHave" id ="indoorParking" /><label for="indoorParking">Indoor Parking</label>
								<input type="checkbox" name="niceToHave" id="outputParking" /><label for="outputParking">Output Parking</label>
								<input type="checkbox" name="niceToHave" id ="balcony" /><label for="balcony">Balcony</label>
							</p>
						</li>
					</ul>
			</fieldset>

			Let's see what we can find ... <br>

			<input type="submit" id="submit" value="Search" />
			<input type="reset" id="reset" value="Start over" />
    </form>
  </div>
  <div id="loginBox">
    <a onClick="clearMain(); loginForm(); return false;" href="">Log in...</a>
  </div>
</div>
<div id="footer">
  <?php include 'footer.php' ?>
</div>

</body>
</html>
