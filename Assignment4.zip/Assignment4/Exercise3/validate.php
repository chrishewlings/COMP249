<?php
  $matchStr = '/\d\d\d-\d\d\d-\d\d\d\d/';
  preg_match($matchStr, $_POST['phoneNumber'], $matches);

  if(count($matches) != 0) {
    echo $_POST['phoneNumber'] . " is a valid phone number!";
  } else {
    echo "Phone number input was incorrect. Please press your browsers Back button and fill out the form again.";
  }

?>
