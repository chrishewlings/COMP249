<?php ob_start(); ?>

<?php


  if(!isset($_COOKIE['NUM_VISITS'])){
    setcookie("NUM_VISITS", 1);
    $firstTime = true;
    $visitTime = date("D M j G:i:s T Y");
    setcookie("LAST_VISIT", $visitTime, time() + 3600);
  } else {
    $numVisits = $_COOKIE['NUM_VISITS'];
    $numVisits++;
    setcookie("NUM_VISITS", $numVisits, time() + 3600);
    $visitTime = date("D M j G:i:s T Y");
    setcookie("LAST_VISIT", $visitTime, time() + 3600);
  }

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">

  <title>Exercise 2</title>
</head>
<body>
  <?php


    if($firstTime == true) {
      echo "<h2>Welcome to my webpage! It is your first time that you are here.</h2>";
      $firstTime = false;
    } else {
        $numVisits = $_COOKIE['NUM_VISITS'];
        echo "<h2>Hello, this is the " . $numVisits . " time that you are visiting my webpage.</h2>";
        echo "<h4>Last time you visited my webpage on : </h4>" . $_COOKIE['LAST_VISIT'];
    }


  ?>
</body>
</html>

<?php ob_end_flush(); ?>
