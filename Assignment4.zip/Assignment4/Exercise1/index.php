<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Exercise 1</title>
</head>
<body>
  <?php
    function findSummation($number) {
      if(!is_integer($number)) {
        return false;
      }
      if($number <= 0 ) {
        return false;
      }

      $sum = 0;

      for($i = 0; $i <= $number; $i++) {
        $sum += $i;
      }

      return $sum;
    }

    function uppercaseFirstandLast($str) {
      if(!is_string($str)) {
        return false;
      }
      else {
        $length = strlen($str);

        $first = substr($str,0,1);
        $last = substr($str, ($length - 1) );
        $final = strtoupper($first).substr($str,1, ($length - 2) ).strtoupper($last);
        return $final;
      }
    }

    function findAverage_and_Median($arr) {
      // We need the array sorted to find the median
      asort($arr);

      $arrLen = count($arr);

      $sum = 0;


      foreach($arr as $item) {
        $sum += $item;
      }

      $average = $sum / $arrLen;

      // If there are an even number of indices, divide it right down the middle
      // and take the number on either side.

      if( ($arrLen % 2) == 0) {
        $evenMedianLowerIndex = floor(($arrLen + 1) / 2) - 1; // need to subtract one because of zero-index arrays
        $evenMedianUpperIndex = ceil(($arrLen + 1) / 2) - 1;

        $evenMedianLowerValue = $arr[$evenMedianLowerIndex];
        $evenMedianUpperValue = $arr[$evenMedianUpperIndex];

        $median = ($evenMedianLowerValue + $evenMedianUpperValue) / 2;
      } else { // if there are an odd number of elements
        $oddMedianIndex = (($arrLen + 1) / 2) - 1;
        $median = $arr[$oddMedianIndex];
      }
      // Return both values as an array
      return array("Average" => $average, "Median" => $median);

    }

    function find4Digits($inputStr) {
      if(!is_string($inputStr)) {
        return false;
      }

      $matchStr = '/[0-9][0-9][0-9][0-9]/';

      preg_match( $matchStr, $inputStr, $matches);

      if(count($matches) == 0) {
        return false;
      } else {
        return $matches[0];
      }

    }



    echo "<h3>Testing findSummation function for number 9...:</h3>" . "\n";
    echo findSummation(9);
    echo "<h3>Testing findSummation function for number 21...:</h3>" . "\n";
    echo findSummation(21);

    echo "<h3>Testing uppercaseFirstandLast on string \"hello world\"...:</h3>";
    echo uppercaseFirstandLast("hello world");

    echo "<h3>Testing uppercaseFirstandLast on string \"salad\"...:</h3>";
    echo uppercaseFirstandLast("salad");

    $firstNumArr = array(2,4,7,10,14,22);
    echo "<h3>Testing findAverage_and_Median on array (2,4,7,10,14,22)...:</h3>";
    print_r(findAverage_and_Median($firstNumArr));

    $secondNumArr = array(1,4,9,16,25);
    echo "<h3>Testing findAverage_and_Median on array (1,4,9,16,25)...:</h3>";
    print_r(findAverage_and_Median($secondNumArr));

    $firstMatchString = "123 12 987 6785";
    echo "<h3>Testing find4Digits on string \"123 12 987 6785 123 866 1\"...:</h3>";
    echo find4Digits($firstMatchString);

    $secondMatchString = "986 121 144 212 713";
    echo "<h3>Testing find4Digits on string \"986 121 144 212 713\"...:</h3>";
    echo find4Digits($secondMatchString);
   ?>
</body>
</html>
